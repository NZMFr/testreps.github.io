/* ---------- Stats page ---------- */
let data = loadData();

document.addEventListener("DOMContentLoaded", async () => {
  bindTransitions();
  applySettings(data);

  document.getElementById("greeting").textContent = greetingText(data);

  let games = [];
  try {
    const res = await fetch("data/games.json");
    games = await res.json();
  } catch (e) {}

  const streak = computeStreak(data);
  document.getElementById("streak-now").textContent = streak;
  document.getElementById("streak-best").textContent = Math.max(data.longestStreak, streak);
  document.getElementById("total-time").textContent = fmtDuration(totalPlaytime(data));

  const playedEntries = Object.entries(data.playtime).filter(([, t]) => t > 0);
  document.getElementById("games-played").textContent = playedEntries.length;

  // favorite category by playtime
  const catTime = {};
  games.forEach(g => {
    const t = data.playtime[g.id] || 0;
    if (t > 0) catTime[g.category] = (catTime[g.category] || 0) + t;
  });
  const favCat = Object.entries(catTime).sort((a, b) => b[1] - a[1])[0];
  document.getElementById("fav-cat").textContent = favCat ? favCat[0] : "—";

  // leaderboard
  const lb = document.getElementById("leaderboard");
  const sorted = playedEntries.sort((a, b) => b[1] - a[1]).slice(0, 10);
  const max = sorted.length ? sorted[0][1] : 1;

  sorted.forEach(([gid, t], i) => {
    const g = games.find(x => x.id === gid);
    const row = document.createElement("div");
    row.className = "lb-row";
    row.innerHTML = `
      <div class="lb-rank ${i === 0 ? "crown" : ""}">${i === 0 ? "👑" : "#" + (i + 1)}</div>
      <div class="lb-name">${g ? g.title : gid}</div>
      <div class="lb-bar-wrap"><div class="lb-bar" style="width:${Math.max(4, (t / max) * 100)}%"></div></div>
      <div class="lb-time">${fmtDuration(t)}</div>`;
    lb.appendChild(row);
  });

  document.getElementById("no-stats").classList.toggle("hidden", sorted.length > 0);
});
