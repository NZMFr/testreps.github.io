/* ---------- Player page: iframe + playtime heartbeat + shortcuts ---------- */
const params = new URLSearchParams(location.search);
const id = params.get("id");
let game = null;
let muted = false;

document.addEventListener("DOMContentLoaded", () => {
  bindTransitions();
  document.body.classList.add("loaded"); // in case common already did
});

fetch("data/games.json")
  .then(r => r.json())
  .then(games => {
    game = games.find(g => g.id === id);
    if (!game) {
      document.getElementById("game-title").textContent = "Game not found";
      return;
    }
    document.title = game.title;
    document.getElementById("game-title").textContent = game.title;
    document.getElementById("game-dev").textContent = game.developer ? "by " + game.developer : "";
    const frame = document.getElementById("frame");
    frame.src = game.url;

    // initial time pill
    const d0 = loadData();
    document.getElementById("time-pill").textContent = "⏱ " + fmtDuration(d0.playtime[game.id] || 0);

    // heartbeat: count playtime every 5s while tab is visible
    setInterval(() => {
      if (document.visibilityState !== "visible" || !game) return;
      const d = loadData();
      d.playtime[game.id] = (d.playtime[game.id] || 0) + 5;
      const k = fmtDate(new Date());
      d.visits[k] = (d.visits[k] || 0) + 5;
      saveData(d);
      document.getElementById("time-pill").textContent = "⏱ " + fmtDuration(d.playtime[game.id]);
    }, 5000);

    document.getElementById("fullscreen-btn").onclick = toggleFullscreen;
    document.getElementById("newtab-btn").onclick = () => window.open(game.url, "_blank");
    document.getElementById("close-btn").onclick = () => fadeTo("index.html");

    // mute: best effort — mutes <video>/<audio> inside same-origin games
    document.getElementById("mute-btn").onclick = e => {
      muted = !muted;
      e.target.textContent = muted ? "🔇" : "🔊";
      try {
        frame.contentDocument.querySelectorAll("video, audio").forEach(m => (m.muted = muted));
      } catch (err) { /* cross-origin: can't reach inside */ }
    };

    // shortcuts: Esc = back home (or exit fullscreen), F = fullscreen
    document.addEventListener("keydown", e => {
      if (e.key === "Escape") {
        if (document.fullscreenElement) document.exitFullscreen();
        else fadeTo("index.html");
      }
      if (e.key.toLowerCase() === "f") toggleFullscreen();
    });
  });

function toggleFullscreen() {
  const frame = document.getElementById("frame");
  if (!document.fullscreenElement) {
    if (frame.requestFullscreen) frame.requestFullscreen();
    else if (frame.webkitRequestFullscreen) frame.webkitRequestFullscreen();
  } else {
    document.exitFullscreen();
  }
}
