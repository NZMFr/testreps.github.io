/* ---------- shared: storage, streaks, time, sounds, transitions ---------- */
const STORE_KEY = "launcher-data";

function loadData() {
  const def = {
    settings: { accent: "#c4b5fd", cloak: false, ambient: true, sounds: false, nickname: "" },
    playtime: {},   // gameId -> seconds
    visits: {},     // "YYYY-MM-DD" -> seconds played that day (any visit counts for streaks)
    longestStreak: 0,
    recent: [],     // gameIds, most recent first
    favorites: []   // gameIds
  };
  try {
    const d = JSON.parse(localStorage.getItem(STORE_KEY) || "{}");
    return { ...def, ...d, settings: { ...def.settings, ...(d.settings || {}) } };
  } catch (e) { return def; }
}

function saveData(d) { localStorage.setItem(STORE_KEY, JSON.stringify(d)); }

function fmtDate(d) {
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
function isWeekend(d) { const g = d.getDay(); return g === 0 || g === 6; }

/* Daily streak: consecutive days with activity. Weekends are freeze days —
   missing a Sat/Sun never breaks the streak. */
function computeStreak(data) {
  const keys = Object.keys(data.visits);
  if (!keys.length) return 0;
  const last = new Date(keys.sort()[keys.length - 1] + "T00:00:00");
  const today = new Date(fmtDate(new Date()) + "T00:00:00");
  if (last > today) return 0;
  let streak = 0, d = new Date(last);
  while (d <= today) {
    const k = fmtDate(d);
    if (data.visits[k]) streak++;
    else if (!isWeekend(d)) return 0;
    d.setDate(d.getDate() + 1);
  }
  return streak;
}

function updateStreak(data) {
  const k = fmtDate(new Date());
  if (!data.visits[k]) data.visits[k] = 0;
  const s = computeStreak(data);
  if (s > data.longestStreak) data.longestStreak = s;
  saveData(data);
  return s;
}

function fmtDuration(sec) {
  sec = Math.floor(sec || 0);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  if (h) return h + "h " + m + "m";
  if (m) return m + "m";
  return sec + "s";
}

function totalPlaytime(data) {
  return Object.values(data.playtime).reduce((a, b) => a + b, 0);
}

function greetingText(data) {
  const n = data.settings.nickname;
  return n ? "Welcome back, " + n + " 👋" : "Welcome 👋";
}

/* ---------- UI sounds (off by default) ---------- */
let audioCtx;
function clickSound(data) {
  if (!data.settings.sounds) return;
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.frequency.value = 620; o.type = "sine";
    g.gain.setValueAtTime(0.06, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.08);
    o.connect(g).connect(audioCtx.destination);
    o.start(); o.stop(audioCtx.currentTime + 0.09);
  } catch (e) {}
}

/* ---------- Smooth page transitions ---------- */
function fadeTo(url) {
  document.body.classList.remove("loaded");
  setTimeout(() => location.href = url, 220);
}
function bindTransitions() {
  document.body.classList.add("loaded");
  document.addEventListener("click", e => {
    const a = e.target.closest("a[href]");
    if (!a) return;
    const href = a.getAttribute("href");
    if (!href || href.startsWith("#") || href.startsWith("http") || a.target === "_blank") return;
    e.preventDefault();
    fadeTo(href);
  });
}

function applySettings(data) {
  document.documentElement.style.setProperty("--accent", data.settings.accent);
  document.body.classList.toggle("ambient", data.settings.ambient);
}
