/* ---------- Home page ---------- */
let GAMES = [];
let data = loadData();
let activeCategory = "All";
let searchTerm = "";

const ACCENTS = ["#c4b5fd", "#a78bfa", "#7dd3fc", "#f9a8d4", "#86efac", "#fde68a", "#e9d5ff"];
const PLACEHOLDER = "assets/games/placeholder.png";

document.addEventListener("DOMContentLoaded", async () => {
  bindTransitions();
  applySettings(data);

  // streak: visiting the site counts
  const streak = updateStreak(data);
  if (streak > 0) {
    document.getElementById("streak-pill").classList.remove("hidden");
    document.getElementById("streak-n").textContent = streak;
  }
  document.getElementById("greeting").textContent = greetingText(data);

  buildAccentPicker();
  bindSettingsModal();
  bindSearch();
  document.getElementById("random-btn").onclick = () => {
    if (!GAMES.length) return;
    clickSound(data);
    openGame(GAMES[Math.floor(Math.random() * GAMES.length)]);
  };

  try {
    const res = await fetch("data/games.json");
    GAMES = await res.json();
  } catch (e) { GAMES = []; }

  buildChips();
  render();
});

/* ---------- Settings ---------- */
function buildAccentPicker() {
  const wrap = document.getElementById("accents");
  ACCENTS.forEach(color => {
    const s = document.createElement("div");
    s.className = "swatch" + (data.settings.accent === color ? " selected" : "");
    s.style.background = color;
    s.onclick = () => {
      data.settings.accent = color;
      applySettings(data);
      [...wrap.children].forEach(x => x.classList.toggle("selected", x === s));
    };
    wrap.appendChild(s);
  });
}

function bindSettingsModal() {
  const backdrop = document.getElementById("modal-backdrop");
  document.getElementById("settings-btn").onclick = () => {
    document.getElementById("nickname-input").value = data.settings.nickname;
    document.getElementById("cloak-toggle").checked = data.settings.cloak;
    document.getElementById("ambient-toggle").checked = data.settings.ambient;
    document.getElementById("sounds-toggle").checked = data.settings.sounds;
    backdrop.classList.remove("hidden");
  };
  document.getElementById("close-btn").onclick = () => backdrop.classList.add("hidden");
  backdrop.onclick = e => { if (e.target === backdrop) backdrop.classList.add("hidden"); };
  document.getElementById("save-btn").onclick = () => {
    data.settings.nickname = document.getElementById("nickname-input").value.trim();
    data.settings.cloak = document.getElementById("cloak-toggle").checked;
    data.settings.ambient = document.getElementById("ambient-toggle").checked;
    data.settings.sounds = document.getElementById("sounds-toggle").checked;
    saveData(data);
    applySettings(data);
    document.getElementById("greeting").textContent = greetingText(data);
    backdrop.classList.add("hidden");
  };
}

/* ---------- Search & chips ---------- */
function bindSearch() {
  document.getElementById("search").addEventListener("input", e => {
    searchTerm = e.target.value.trim().toLowerCase();
    render();
  });
}

function buildChips() {
  const cats = ["All", "⭐ Favorites", ...new Set(GAMES.map(g => g.category).filter(Boolean))];
  const wrap = document.getElementById("chips");
  wrap.innerHTML = "";
  cats.forEach(cat => {
    const b = document.createElement("button");
    b.className = "chip" + (cat === activeCategory ? " active" : "");
    b.textContent = cat;
    b.onclick = () => { activeCategory = cat; clickSound(data); buildChips(); render(); };
    wrap.appendChild(b);
  });
}

/* ---------- Filtering ---------- */
function filtered() {
  return GAMES.filter(g => {
    const matchCat =
      activeCategory === "All" ? true :
      activeCategory === "⭐ Favorites" ? data.favorites.includes(g.id) :
      g.category === activeCategory;
    const matchSearch = !searchTerm || g.title.toLowerCase().includes(searchTerm);
    return matchCat && matchSearch;
  });
}

/* ---------- Cards ---------- */
function cardEl(g, wide) {
  const el = document.createElement("div");
  el.className = "card";
  const played = data.playtime[g.id] || 0;
  const isFav = data.favorites.includes(g.id);
  el.innerHTML = `
    <img src="${g.image}" alt="${g.title}" loading="lazy" onerror="this.onerror=null;this.src='${PLACEHOLDER}'">
    ${g.isNew ? '<span class="badge new">NEW!</span>' : ''}
    ${played ? `<span class="badge time">⏱ ${fmtDuration(played)}</span>` : ''}
    <button class="star ${isFav ? "on" : ""}" title="Favorite">${isFav ? "★" : "☆"}</button>
    <div class="label">${g.title}</div>`;
  el.querySelector(".star").onclick = e => {
    e.stopPropagation();
    toggleFav(g.id);
  };
  el.onclick = () => { clickSound(data); openGame(g); };
  return el;
}

function toggleFav(id) {
  const i = data.favorites.indexOf(id);
  if (i >= 0) data.favorites.splice(i, 1);
  else data.favorites.push(id);
  saveData(data);
  clickSound(data);
  render();
}

/* ---------- Render ---------- */
function showSection(id, show) {
  document.getElementById(id).classList.toggle("hidden", !show);
}

function render() {
  const browsing = !searchTerm && activeCategory === "All";

  // sections only in plain browse mode
  showSection("recent-section", browsing && data.recent.length > 0);
  showSection("fav-section", browsing && data.favorites.length > 0);
  const feat = browsing ? GAMES.filter(g => g.isNew || g.featured) : [];
  showSection("featured-section", feat.length > 0);

  const recent = document.getElementById("recent");
  recent.innerHTML = "";
  if (browsing) {
    data.recent.map(id => GAMES.find(g => g.id === id)).filter(Boolean)
      .forEach(g => recent.appendChild(cardEl(g)));
  }

  const favs = document.getElementById("favs");
  favs.innerHTML = "";
  if (browsing) {
    GAMES.filter(g => data.favorites.includes(g.id)).forEach(g => favs.appendChild(cardEl(g)));
  }

  const featured = document.getElementById("featured");
  featured.innerHTML = "";
  feat.forEach(g => featured.appendChild(cardEl(g, true)));

  // main grid: new games first
  const grid = document.getElementById("grid");
  grid.innerHTML = "";
  const list = filtered().sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0) || a.title.localeCompare(b.title));
  list.forEach(g => grid.appendChild(cardEl(g)));

  document.getElementById("empty").classList.toggle("hidden", list.length > 0);
}

/* ---------- Launch ---------- */
function openGame(g) {
  data.recent = [g.id, ...data.recent.filter(id => id !== g.id)].slice(0, 12);
  saveData(data);
  if (data.settings.cloak) {
    const w = window.open("about:blank", "_blank");
    if (w) w.location.href = location.href.replace(/[^/]*$/, "") + "game.html?id=" + encodeURIComponent(g.id);
    return;
  }
  fadeTo("game.html?id=" + encodeURIComponent(g.id));
}
